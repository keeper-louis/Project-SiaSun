﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Keeper.Siasun.Mes.Project
{
    public class MaterialGroup
    {
        public string FID { get; set; }

        public string FNUMBER { get; set; }

        public string FNAME { get; set; }

        public string FPARENTID { get; set; }

        public string FFULLPARENTID { get; set; }
    }
}
